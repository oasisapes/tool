import React from 'react'
import styled from 'styled-components'

function Header( { connect, account }) {

    const HeaderDiv = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    align-content: center;
    flex-direction: row;
    background-color: grey;
    height: 50px;
    padding-left: 20px;
    padding-right: 20px;
    `;

    const HeaderA = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    align-content: center;
    flex-direction: row;
    `;

    const HeaderB = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;
    align-content: center;
    flex-direction: row;
    gap: 20px;
    `;

    const Button = styled.button`
    color: white;
    background: darkcyan;
    width: 150px;
    height: 30px;
    border: 1px solid black;
    border-radius: 5px;
    :hover {
        color: black;
        background: cyan;
    }
    `;


  return (
      <HeaderDiv>
          <HeaderA>
              <img src="/images/logo.svg" alt="" />
          </HeaderA>
          <HeaderB>
              <Button
                    onClick={(e) => {
                        e.preventDefault();
                        connect();
                      }}
              >
                  {account === null ? (
                      <>
                     Connect Wallet
                      </>
                  ) : (
                      <>
                      Connected
                      </>
                  )}

              </Button>
          </HeaderB>

      </HeaderDiv>

  )
}

export default Header