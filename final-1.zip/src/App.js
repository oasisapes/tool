/* eslint-disable no-unused-vars */
import './App.css';
import Web3 from 'web3';
import Web3EthContract from "web3-eth-contract";
import { useState, useRef } from 'react';
import Header from './components/Header';
import styled from 'styled-components';
import { Input, InputGroup } from 'rsuite';
import "rsuite/dist/rsuite.min.css";
import { on } from 'process';
import { once } from 'events';
const axios = require('axios').default;

const Screen = styled.div`
width: 100%;
height: 100vh;
background-color: white;
`;

const InputDiv = styled.div`
width: 100%;
background: white;
height: 50%;
display: flex;
align-items: center;
justify-content: center;
align-content: center;
flex-direction: column;
}
`;

const InputDivResult = styled.div`
width: 100%;
height: fit-content;
background: grey;
display: flex;
align-items: center;
justify-content: flex-start;
align-content: center;
flex-direction: column;
}
`;

const styles = {
  width: 700,
  marginBottom: 15,
  marginTop: 15
};

const Button = styled.button`
color: cyan;
background: grey;
width: 150px;
height: 30px;
border: 1px solid black;
border-radius: 5px;
:hover {
    color: white;
    background: black;
}
`;

const ResultDiv = styled.div`
display: grid;
grid-template-columns: repeat(5, 1fr);
gap: 55px;
margin-top: 20px;
margin-bottom: 50px;
`;

const ResultDivAllow = styled.div`
display: flex;
grid-template-columns: repeat(5, 1fr);
gap: 55px;
margin-top: 20px;
margin-bottom: 50px;
`;

const SwapDiv = styled.div`
display: flex;
width: 100%;
flex-direction: row;
align-items: flex-start;
justify-content: space-evenly;
`;

const ResultDiv2 = styled.div`
display: flex;
margin-top: 20px;
`;

const MSGDiv = styled.div`
display: flex;
align-items: center;
justify-content: center;
margin-bottom: 20px;
`;

const ERRMSG = styled.p`
color: black;
font-size: 1rem;
font-weight: bold;
letter-spacing: 1px;
`;

const LINKSTYLED = styled.a`
color: red;
cursor: pointer;
:hover {
  color: blue;
}
`;

function App() {

  const [account, setaccount] = useState(null);
  const [Tokens, setTokens] = useState("");
  const [Balance, setBalance] = useState("");
  const [RosePrice, setRosePRICE] = useState(0);
  const [Networth ,setTOTALUSD] = useState();
  const [ROSETOTALUSD ,setROSETOTALUSD] = useState();

  const [VallyCT, setVallyCT] = useState();
  const [VallyAL, setVallyAL] = useState(0);
  const [VallyAL2, setVallyAL2] = useState(0);
  const [VallyAL3, setVallyAL3] = useState(0);
  const [VallyAL4, setVallyAL4] = useState(0);

  const [BlingCT, setBlingCT] = useState();
  const [BlingAL, setBlingAL] = useState(0);
  const [BlingAL2, setBlingAL2] = useState(0);
  const [BlingAL3, setBlingAL3] = useState(0);
  const [BlingAL4, setBlingAL4] = useState(0);

  const [YuzuCT, setYuzuCT] = useState();
  const [YuzuAL, setYuzuAL] = useState(0);
  const [YuzuAL2, setYuzuAL2] = useState(0);
  const [YuzuAL3, setYuzuAL3] = useState(0);
  const [YuzuAL4, setYuzuAL4] = useState(0);

  const [WethCT, setWethCT] = useState();
  const [WethAL, setWethAL] = useState(0);
  const [WethAL2, setWethAL2] = useState(0);
  const [WethAL3, setWethAL3] = useState(0);
  const [WethAL4, setWethAL4] = useState(0);
  const [WethAL5, setWethAL5] = useState(0);

  const [ceUSDCCT, setceUSDCCT] = useState();
  const [ceUSDCAL, setceUSDCAL] = useState(0);
  const [ceUSDCAL2, setceUSDCAL2] = useState(0);
  const [ceUSDCAL3, setceUSDCAL3] = useState(0);
  const [ceUSDCAL4, setceUSDCAL4] = useState(0);

  const [FTPCT, setFTPCT] = useState();
  const [FTPAL, setFTPAL] = useState(0);
  const [FTPAL2, setFTPAL2] = useState(0);
  const [FTPAL3, setFTPAL3] = useState(0);
  const [FTPAL4, setFTPAL4] = useState(0);

  const [weUSDTCT, setweUSDTCT] = useState();
  const [weUSDTAL, setweUSDTAL] = useState(0);
  const [weUSDTAL2, setweUSDTAL2] = useState(0);
  const [weUSDTAL3, setweUSDTAL3] = useState(0);
  const [weUSDTAL4, setweUSDTAL4] = useState(0);

  const [BTCCT, setBTCCT] = useState();
  const [BTCAL, setBTCAL] = useState(0);
  const [BTCAL2, setBTCAL2] = useState(0);
  const [BTCAL3, setBTCAL3] = useState(0);
  const [BTCAL4, setBTCAL4] = useState(0);

  const [USDCCT, setUSDCCT] = useState();
  const [USDCAL, setUSDCAL] = useState(0);
  const [USDCAL2, setUSDCAL2] = useState(0);
  const [USDCAL3, setUSDCAL3] = useState(0);
  const [USDCAL4, setUSDCAL4] = useState(0);
  const [USDCAL5, setUSDCAL5] = useState(0);

  const [ETHCT, setETHCT] = useState();
  const [ETHAL, setETHAL] = useState(0);
  const [ETHAL2, setETHAL2] = useState(0);
  const [ETHAL3, setETHAL3] = useState(0);
  const [ETHAL4, setETHAL4] = useState(0);
  const [ETHAL5, setETHAL5] = useState(0);

  const [USDTCT, setUSDTCT] = useState();
  const [USDTAL, setUSDTAL] = useState(0);
  const [USDTAL2, setUSDTAL2] = useState(0);
  const [USDTAL3, setUSDTAL3] = useState(0);
  const [USDTAL4, setUSDTAL4] = useState(0);

  const [LINKCT, setLINKCT] = useState();
  const [LINKAL, setLINKAL] = useState(0);
  const [LINKAL2, setLINKAL2] = useState(0);
  const [LINKAL3, setLINKAL3] = useState(0);
  const [LINKAL4, setLINKAL4] = useState(0);

  const [WROSECT, setWROSECT] = useState();
  const [WROSEAL, setWROSEAL] = useState(0);
  const [WROSEAL2, setWROSEAL2] = useState(0);
  const [WROSEAL3, setWROSEAL3] = useState(0);
  const [WROSEAL4, setWROSEAL4] = useState(0);

  const [web3, setweb3] = useState(null);
  const [msg, setmsg] = useState(null);
  const accountInputRef = useRef();

  let VallyswapFarm = "0x7C0b0a525fc6A2caDf7AE37198119025C6feA28a";
  let MasterChefFarm = "0x05243Bd7778a9D5556AFC98Ae9D222Cdf5E7C704";
  let yuzuPark = "0x250d48C5E78f1E85F7AB07FEC61E93ba703aE668";
  let Uniswap = "0x543d97779ca53d7b4355cA013C853D86B7F558d9";
  let bridgeoasis = "0x9983D8cDEAf7872501628229d311E2F7Df396aDd";
  let vallyabi = [{"type":"constructor","stateMutability":"nonpayable","inputs":[]},{"type":"event","name":"Approval","inputs":[{"type":"address","name":"owner","internalType":"address","indexed":true},{"type":"address","name":"spender","internalType":"address","indexed":true},{"type":"uint256","name":"value","internalType":"uint256","indexed":false}],"anonymous":false},{"type":"event","name":"OwnershipTransferred","inputs":[{"type":"address","name":"previousOwner","internalType":"address","indexed":true},{"type":"address","name":"newOwner","internalType":"address","indexed":true}],"anonymous":false},{"type":"event","name":"Transfer","inputs":[{"type":"address","name":"from","internalType":"address","indexed":true},{"type":"address","name":"to","internalType":"address","indexed":true},{"type":"uint256","name":"value","internalType":"uint256","indexed":false}],"anonymous":false},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"","internalType":"uint256"}],"name":"allowance","inputs":[{"type":"address","name":"owner","internalType":"address"},{"type":"address","name":"spender","internalType":"address"}]},{"type":"function","stateMutability":"nonpayable","outputs":[{"type":"bool","name":"","internalType":"bool"}],"name":"approve","inputs":[{"type":"address","name":"spender","internalType":"address"},{"type":"uint256","name":"amount","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"","internalType":"uint256"}],"name":"balanceOf","inputs":[{"type":"address","name":"account","internalType":"address"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"burn","inputs":[{"type":"uint256","name":"amount","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"burnFrom","inputs":[{"type":"address","name":"account","internalType":"address"},{"type":"uint256","name":"amount","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint8","name":"","internalType":"uint8"}],"name":"decimals","inputs":[]},{"type":"function","stateMutability":"nonpayable","outputs":[{"type":"bool","name":"","internalType":"bool"}],"name":"decreaseAllowance","inputs":[{"type":"address","name":"spender","internalType":"address"},{"type":"uint256","name":"subtractedValue","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[{"type":"bool","name":"","internalType":"bool"}],"name":"increaseAllowance","inputs":[{"type":"address","name":"spender","internalType":"address"},{"type":"uint256","name":"addedValue","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"mint","inputs":[{"type":"address","name":"to","internalType":"address"},{"type":"uint256","name":"amount","internalType":"uint256"}]},{"type":"function","stateMutability":"view","outputs":[{"type":"string","name":"","internalType":"string"}],"name":"name","inputs":[]},{"type":"function","stateMutability":"view","outputs":[{"type":"address","name":"","internalType":"address"}],"name":"owner","inputs":[]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"renounceOwnership","inputs":[]},{"type":"function","stateMutability":"view","outputs":[{"type":"string","name":"","internalType":"string"}],"name":"symbol","inputs":[]},{"type":"function","stateMutability":"view","outputs":[{"type":"uint256","name":"","internalType":"uint256"}],"name":"totalSupply","inputs":[]},{"type":"function","stateMutability":"nonpayable","outputs":[{"type":"bool","name":"","internalType":"bool"}],"name":"transfer","inputs":[{"type":"address","name":"recipient","internalType":"address"},{"type":"uint256","name":"amount","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[{"type":"bool","name":"","internalType":"bool"}],"name":"transferFrom","inputs":[{"type":"address","name":"sender","internalType":"address"},{"type":"address","name":"recipient","internalType":"address"},{"type":"uint256","name":"amount","internalType":"uint256"}]},{"type":"function","stateMutability":"nonpayable","outputs":[],"name":"transferOwnership","inputs":[{"type":"address","name":"newOwner","internalType":"address"}]}];

  let Vallyswaptoken = "0xBC033203796CC2C8C543a5aAe93a9a643320433D";
  let bling = "0x72Ad551af3c884d02e864B182aD9A34EE414C36C";
  let yuzutoken = "0xf02b3e437304892105992512539F769423a515Cb";
  let weth = "0x3223f17957Ba502cbe71401D55A0DB26E5F7c68F";
  let ceUSDC = "0x81ECac0D6Be0550A00FF064a4f9dd2400585FE9c";
  let FTP = "0xd1dF9CE4b6159441D18BD6887dbd7320a8D52a05";
  let weUSDT = "0xdC19A122e268128B5eE20366299fc7b5b199C8e3";
  let BTC = "0x010CDf0Db2737f9407F8CFcb4dCaECA4dE54c815";
  let USDC = "0x94fbfFe5698DB6f54d6Ca524DbE673a7729014Be"; 
  let ETH = "0xE9b38eD157429483EbF87Cf6C002cecA5fd66783"; 
  let USDT = "0x6Cb9750a92643382e020eA9a170AbB83Df05F30B"; 
  let LINK = "0xc9BAA8cfdDe8E328787E29b4B078abf2DaDc2055"; 
  let WROSE = "0x21C718C22D52d0F3a789b752D4c2fD5908a8A733"; 
   

  let Vallyswaptokenadd = "https://explorer.emerald.oasis.dev/address/0xaE0aF27df228ACd8BA91AF0c917a31A9a681A097/write-contract";
  let blingadd = "https://explorer.emerald.oasis.dev/address/0x05243Bd7778a9D5556AFC98Ae9D222Cdf5E7C704/write-contract";
  let yuzutokenadd = "https://explorer.emerald.oasis.dev/address/0xB759803Ee7087559EB601a4939c2d5da7668385a/write-contract";

  const connect = async() => {
      const { ethereum } = window;
      const metamaskIsInstalled = ethereum && ethereum.isMetaMask;
      if (metamaskIsInstalled) {
        Web3EthContract.setProvider(ethereum);
        let web3 = new Web3(ethereum);
        setweb3(web3);
          const accounts = await ethereum.request({
            method: "eth_requestAccounts",
          });
          setaccount(accounts[0]);

          const networkId = await ethereum.request({
            method: "net_version",
          });

          if (networkId === '42262') {
            let Vally = new Web3EthContract(
              vallyabi,
              Vallyswaptoken
            );
            setVallyCT(Vally);
  
            let blingg = new Web3EthContract(
              vallyabi,
              bling
            );
            setBlingCT(blingg);
  
            let yuzutokenn = new Web3EthContract(
              vallyabi,
              yuzutoken
            );
            setYuzuCT(yuzutokenn);

            let wethcontract = new Web3EthContract(
              vallyabi,
              weth
            );
            setWethCT(wethcontract);

            let ceUSDCcontract = new Web3EthContract(
              vallyabi,
              ceUSDC
            );
            setceUSDCCT(ceUSDCcontract);

            let FTPcontract = new Web3EthContract(
              vallyabi,
              FTP
            );
            setFTPCT(FTPcontract);

            let weusdtcontract = new Web3EthContract(
              vallyabi,
              weUSDT
            );
            setweUSDTCT(weusdtcontract);


            let BTCcontract = new Web3EthContract(
              vallyabi,
              BTC
            );
            setBTCCT(BTCcontract);


            let USDCcontract = new Web3EthContract(
              vallyabi,
              USDC
            );
            setUSDCCT(USDCcontract);


            let ETHcontract = new Web3EthContract(
              vallyabi,
              ETH
            );
            setETHCT(ETHcontract);


            let USDTcontract = new Web3EthContract(
              vallyabi,
              USDT
            );
            setUSDTCT(USDTcontract);

            let LINKcontract = new Web3EthContract(
              vallyabi,
              LINK
            );
            setLINKCT(LINKcontract);

            let WROSEcontract = new Web3EthContract(
              vallyabi,
              WROSE
            );
            setWROSECT(WROSEcontract);


            ethereum.on("accountsChanged", (accounts) => {
             setaccount(accounts[0])
            });
            ethereum.on("chainChanged", () => {
               window.location.reload();
             });
            setmsg();
          } else {
            setmsg(`Change network to OASIS`);
            setaccount(null);
          }
  };
  };

  const checkallowance = () => {
    VallyCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("Vally: VallyswapFarm", rec);
      setVallyAL(rec);
    });
    VallyCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("Vally: MasterChefFarm1", rec);
      setVallyAL2(rec);
    });
    VallyCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("Vally: yuzuPark", rec);
      setVallyAL3(rec);
    });
    VallyCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("Vally: Uniswap", rec);
      setVallyAL4(rec);
    });


    BlingCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("Bling: VallyswapFarm", rec);
      setBlingAL(rec);
    });
    BlingCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("Bling: MasterChefFarm", rec);
      setBlingAL2(rec);
    });
    BlingCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("Bling: yuzuPark", rec);
      setBlingAL3(rec);
    });
    BlingCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("Bling: Uniswap", rec);
      setBlingAL4(rec);
    });


    YuzuCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("Yuzu: VallyswapFarm", rec);
      setYuzuAL(rec);
    });
    YuzuCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("Yuzu: MasterChefFarm", rec);
      setYuzuAL2(rec);
    });
    YuzuCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("Yuzu: yuzuPark", rec);
      setYuzuAL3(rec);
    });
    YuzuCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("Yuzu: Uniswap", rec);
      setYuzuAL4(rec);
    });


    WethCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("Weth: VallyswapFarm", rec);
      setWethAL(rec);
    });
    WethCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("Weth: MasterChefFarm", rec);
      setWethAL2(rec);
    });
    WethCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("Weth: yuzuPark", rec);
      setWethAL3(rec);
    });
    WethCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("Weth: Uniswap", rec);
      setWethAL4(rec);
    });
    WethCT.methods.allowance(account, bridgeoasis).call({from: account})
    .then((rec) => {
      console.log("ETH: Evodefi Bridge", rec);
      setWethAL5(rec);
    });



    FTPCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("FTP: VallyswapFarm", rec);
      setFTPAL(rec);
    });
    FTPCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("FTP: MasterChefFarm", rec);
      setFTPAL2(rec);
    });
    FTPCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("FTP: yuzuPark", rec);
      setFTPAL3(rec);
    });
    FTPCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("FTP: Uniswap", rec);
      setFTPAL4(rec);
    });



    ceUSDCCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("ceUSDC: VallyswapFarm", rec);
      setceUSDCAL(rec);
    });
    ceUSDCCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("ceUSDC: MasterChefFarm", rec);
      setceUSDCAL2(rec);
    });
    ceUSDCCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("ceUSDC: yuzuPark", rec);
      setceUSDCAL3(rec);
    });
    ceUSDCCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("ceUSDC: Uniswap", rec);
      setceUSDCAL4(rec);
    });



    weUSDTCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("weUSDT: VallyswapFarm", rec);
      setweUSDTAL(rec);
    });
    weUSDTCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("weUSDT: MasterChefFarm", rec);
      setweUSDTAL2(rec);
    });
    weUSDTCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("weUSDT: yuzuPark", rec);
      setweUSDTAL3(rec);
    });
    weUSDTCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("weUSDT: Uniswap", rec);
      setweUSDTAL4(rec);
    });



    BTCCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("BTC: VallyswapFarm", rec);
      setBTCAL(rec);
    });
    BTCCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("BTC: MasterChefFarm", rec);
      setBTCAL2(rec);
    });
    BTCCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("BTC: yuzuPark", rec);
      setBTCAL3(rec);
    });
    BTCCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("BTC: Uniswap", rec);
      setBTCAL4(rec);
    });



    USDCCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("USDC: VallyswapFarm", rec);
      setUSDCAL(rec);
    });
    USDCCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("USDC: MasterChefFarm", rec);
      setUSDCAL2(rec);
    });
    USDCCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("USDC: yuzuPark", rec);
      setUSDCAL3(rec);
    });
    USDCCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("USDC: Uniswap", rec);
      setUSDCAL4(rec);
    });
    USDCCT.methods.allowance(account, bridgeoasis).call({from: account})
    .then((rec) => {
      console.log("USDC: Evodefi Bridge", rec);
      setUSDCAL5(rec);
    });




    ETHCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("ETH: VallyswapFarm", rec);
      setETHAL(rec);
    });
    ETHCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("ETH: MasterChefFarm", rec);
      setETHAL2(rec);
    });
    ETHCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("ETH: yuzuPark", rec);
      setETHAL3(rec);
    });
    ETHCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("ETH: Uniswap", rec);
      setETHAL4(rec);
    });
    ETHCT.methods.allowance(account, bridgeoasis).call({from: account})
    .then((rec) => {
      console.log("ETH: Evodefi Bridge", rec);
      setETHAL5(rec);
    });



    USDTCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("USDT: VallyswapFarm", rec);
      setUSDTAL(rec);
    });
    USDTCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("USDT: MasterChefFarm", rec);
      setUSDTAL2(rec);
    });
    USDTCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("USDT: yuzuPark", rec);
      setUSDTAL3(rec);
    });
    USDTCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("USDT: Uniswap", rec);
      setUSDTAL4(rec);
    });




    LINKCT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("LINK: VallyswapFarm", rec);
      setLINKAL(rec);
    });
    LINKCT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("LINK: MasterChefFarm", rec);
      setLINKAL2(rec);
    });
    LINKCT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("LINK: yuzuPark", rec);
      setLINKAL3(rec);
    });
    LINKCT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("LINK: Uniswap", rec);
      setLINKAL4(rec);
    });


    WROSECT.methods.allowance(account, VallyswapFarm).call({from: account})
    .then((rec) => {
      console.log("WROSE: VallyswapFarm", rec);
      setWROSEAL(rec);
    });
    WROSECT.methods.allowance(account, MasterChefFarm).call({from: account})
    .then((rec) => {
      console.log("WROSE: MasterChefFarm", rec);
      setWROSEAL2(rec);
    });
    WROSECT.methods.allowance(account, yuzuPark).call({from: account})
    .then((rec) => {
      console.log("WROSE: yuzuPark", rec);
      setWROSEAL3(rec);
    });
    WROSECT.methods.allowance(account, Uniswap).call({from: account})
    .then((rec) => {
      console.log("WROSE: Uniswap", rec);
      setWROSEAL4(rec);
    });
  };



  const Search = () => {
    if(account === null) {
      setmsg("Please Connect Wallet")
    } else {
      axios.get(`https://explorer.emerald.oasis.dev/api?module=account&action=tokenlist&address=${account}`)
      .then(function (response) {
        // handle success
        console.log(response.data.result);
        setTokens(response.data.result);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
      .then(function () {
        // always executed
      });
    }

  };

  const SearchB = () => {
    if(account === null) {
      setmsg("Please Connect Wallet")
    } else {
      axios.get(`https://explorer.emerald.oasis.dev/api?module=account&action=balance&address=${account}`)
      .then(function (response) {
        // handle success
        console.log(response.data.result);
        setBalance(response.data.result);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
      .then(function () {
        // always executed
      });
      axios.get(`https://min-api.cryptocompare.com/data/price?fsym=ROSE&tsyms=USD&api_key=4a2cb602b0bfc71020190ecbc035a8cb126141a983238a4aa6ac0266d5d5b00d`)
      .then(function (response) {
        // handle success
        console.log("ROSE PRICE", response.data.USD);
        setRosePRICE(response.data.USD);
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      })
      .then(function () {
        // always executed
      });
    }
  };

  let Wei = Web3.utils.fromWei;

  const TokensofUser = ({ name, balance, symbol, contract }) => {
    const [ppr, setppr] = useState(null);
    axios.get(`https://api.dexscreener.com/latest/dex/tokens/${contract}`)
    .then(function (response) {
      // handle success
      console.log(" PRICE", response.data.pairs[0].priceUsd);
      setppr(response.data.pairs[0].priceUsd);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })
    .then(function () {
      // always executed
    });

    let fullprice = Wei(balance).substring(0,6);
    let usdprice = (fullprice * ppr).toString().substring(0,6);
    return (
        <div className="w-1/4 mr-3 mb-4 bg-slate-100 rounded-md">
           <div className="p-3">
                <div className="flex mb-3">
                    <div className="flex-grow">
                    <p style={{textAlign: "center" , color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                        {`${name}`}
                            </p>
                        <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                        {fullprice} ${symbol} ({usdprice} $USD)
                            </p>
                    </div>
                </div>
            </div>
        </div>
    )
};

const BalanceofUser = ({ balance }) => {
  let usdprice = (balance * RosePrice).toString().substring(0,6);
  setROSETOTALUSD(usdprice);
  return (
      <div className="w-1/4 mr-3 mb-4 bg-slate-100 rounded-md">
         <div className="p-3">
              <div className="flex mb-3">
                  <div className="flex-grow">
                      <p style={{textAlign: "center", color: 'black', fontSize: '1.5rem', fontWeight: 'bolder'}}>
                      {balance} $ROSE ({usdprice} $USD)
                          </p>
                  </div>
              </div>
          </div>
      </div>
  )
};

const TOTALOFUSER = ({ balance }) => {
  return (
      <div className="w-1/4 mr-3 mb-4 bg-slate-100 rounded-md">
         <div className="p-3">
              <div className="flex mb-3">
                  <div className="flex-grow">
                      <p style={{textAlign: "center", color: 'black', fontSize: '1.5rem', fontWeight: 'bolder'}}>
                       ({ROSETOTALUSD} $USD)
                          </p>
                  </div>
              </div>
          </div>
      </div>
  )
};


const AllowofUser = ({ Contract, Contract2, Contract3, Contract4, Contract5, Contract6, Contract7, Contract8, Contract9, Contract10, Contract11, Contract12, Contract13,  Spender, url, name, balance, token, token2, balance2, token3, balance3, token4, balance4, token5, balance5, token6, balance6, token7, balance7, token8, balance8, token9, balance9, token10, balance10, token11, balance11, token12, balance12, token13, balance13 }) => {
  const Revoke = ({ Contract, Spender, Amount }) => {
    Contract.methods.decreaseAllowance(Spender, Amount).send({
      from: account,
      to: Contract,
      gasLimit: 285000,
    })
    .once("error", (err) => {
      console.log(err);
      setmsg("Something Wrong Happend");
      alert("Something Wrong Happend");
      if(err.code === -32602) {
        alert("You Are Not the Owner of address");
        setmsg("You Are Not the Owner of address");
      }
    })
    .then((rec) => {
      console.log("Sucssess", rec);
      setmsg("Succesfull");
    });
  };
  return (
      <div className="w-1/4 mr-3 mb-4 bg-slate-100 rounded-md">
         <div className="p-3">
              <div className="flex mb-3">
                  <div className="flex-grow">
                  <p style={{textAlign: "center" , color: '#a2ff00', fontSize: '1.5rem', fontWeight: 'bolder'}}>
                      {`${name}`} Allowance
                          </p>

                          {balance > 0 ? (
                            <>
                 
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract, Spender:Spender, Amount:balance  });
                      }}> 
                      <img src='/images/vs.png' width={20} alt='vs'/> {token}: {Wei(balance.toString()).substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/vs.png' width={20} alt='vs'/> {token}: 0
                      </p>                         
                            </>
                          )}

                      {balance2 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract2, Spender:Spender, Amount:balance2  });
                      }}> 
                      <img src='/images/bling.png' width={20} alt='bling'/>  {token2}: {`${Wei(balance2).substring(0,6)}`}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/bling.png' width={20} alt='bling'/> {token2}: 0
                      </p>                           
                            </>
                          )}

                     {balance3 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract3, Spender:Spender, Amount:balance3  });
                      }}> 
                      <img src='/images/yuzu.png' width={20} alt='yuzu'/> {token3}: {Wei(balance3.toString()).substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/yuzu.png' width={20} alt='yuzu'/> {token3}: 0
                      </p>                           
                            </>
                          )}

{balance4 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract4, Spender:Spender, Amount:balance4  });
                      }}>
                      <img src='/images/weth.png' width={20} alt='weth'/> {token4}: {Wei(balance4.toString()).substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/weth.png' width={20} alt='weth'/> {token4}: 0
                      </p>                       
                            </>
                          )}

                      {balance5 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract5, Spender:Spender, Amount:balance5  });
                      }}> 
                      <img src='/images/usdc.png' width={20} alt='usdc'/> {token5}: {balance5.toString().substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/usdc.png' width={20} alt='usdc'/> {token5}: 0
                      </p>                           
                            </>
                          )}

                     {balance6 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract6, Spender:Spender, Amount:balance6  });
                      }}> 
                      <img src='/images/ftp.png' width={20} alt='ftp'/>  {token6}: {`${Wei(balance6).substring(0,6)}`}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/ftp.png' width={20} alt='ftp'/>  {token6}: 0
                      </p>                           
                            </>
                          )}
                    {balance7 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract7, Spender:Spender, Amount:balance7  });
                      }}> 
                      <img src='/images/usdt.png' width={20} alt='usdt'/> {token7}: {balance7.toString().substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/usdt.png' width={20} alt='usdt'/> {token7}: 0
                      </p>                           
                            </>
                          )}

                      {balance8 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract8, Spender:Spender, Amount:balance8  });
                      }}> 
                      <img src='/images/btc.png' width={20} alt='btc'/> {token8}: {`${Wei(balance8).substring(0,6)}`}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/btc.png' width={20} alt='btc'/> {token8}: 0
                      </p>                           
                            </>
                          )}

                     {balance9 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract9, Spender:Spender, Amount:balance9  });
                      }}> 
                      <img src='/images/usdc.png' width={20} alt='usdc'/> {token9}: {balance9.toString().substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/usdc.png' width={20} alt='usdc'/> {token9}: 0
                      </p>                           
                            </>
                          )}

{balance10 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract10, Spender:Spender, Amount:balance10  });
                      }}> 
                      <img src='/images/weth.png' width={20} alt='eth'/> {token10}: {`${Wei(balance10).substring(0,6)}`} 
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/weth.png' width={20} alt='eth'/> {token10}: 0
                      </p>                           
                            </>
                          )}

{balance11 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract11, Spender:Spender, Amount:balance11  });
                      }}> 
                      <img src='/images/usdt.png' width={20} alt='usdt'/> {token11}: {balance11.toString().substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/usdt.png' width={20} alt='usdt'/> {token11}: 0
                      </p>                           
                            </>
                          )}

                          
{balance12 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract12, Spender:Spender, Amount:balance12  });
                      }}> 
                      <img src='/images/link.png' width={20} alt='link'/> {token12}: {`${Wei(balance12).substring(0,6)}`}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/link.png' width={20} alt='link'/> {token12}: 0
                      </p>                           
                            </>
                          )}


                          
{balance13 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract13, Spender:Spender, Amount:balance13  });
                      }}> 
                      <img src='/images/wrose.png' width={20} alt='wrose'/> {token13}: {`${Wei(balance13).substring(0,6)}`}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/wrose.png' width={20} alt='usdt'/> {token13}: 0
                      </p>                           
                            </>
                          )}

                  </div>
              </div>
          </div>
      </div>
  )
};



const AllowofUser2 = ({ Contract4, Contract9, Contract10, Spender, url, name, token4, balance4, token9, balance9, token10, balance10 }) => {
  const Revoke = ({ Contract, Spender, Amount }) => {
    Contract.methods.decreaseAllowance(Spender, Amount).send({
      from: account,
      to: Contract,
      gasLimit: 285000,
    })
    .once("error", (err) => {
      console.log(err);
      setmsg("Something Wrong Happend");
      alert("Something Wrong Happend");
      if(err.code === -32602) {
        alert("You Are Not the Owner of address");
        setmsg("You Are Not the Owner of address");
      }
    })
    .then((rec) => {
      console.log("Sucssess", rec);
      setmsg("Succesfull");
    });
  };
  return (
      <div className="w-1/4 mr-3 mb-4 bg-slate-100 rounded-md">
         <div className="p-3">
              <div className="flex mb-3">
                  <div className="flex-grow">
                  <p style={{textAlign: "center" , color: '#a2ff00', fontSize: '1.5rem', fontWeight: 'bolder'}}>
                      {`${name}`} Allowance
                          </p>

{balance4 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract4, Spender:Spender, Amount:balance4  });
                      }}>
                      <img src='/images/weth.png' width={20} alt='weth'/> {token4}: {Wei(balance4.toString()).substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/weth.png' width={20} alt='weth'/> {token4}: 0
                      </p>                       
                            </>
                          )}


                     {balance9 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract9, Spender:Spender, Amount:balance9  });
                      }}> 
                      <img src='/images/usdc.png' width={20} alt='usdc'/> {token9}: {balance9.toString().substring(0,6)}
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/usdc.png' width={20} alt='usdc'/> {token9}: 0
                      </p>                           
                            </>
                          )}

{balance10 > 0 ? (
                            <>
                      <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                      <LINKSTYLED onClick={(e) => {
                        e.preventDefault();
                        Revoke({ Contract:Contract10, Spender:Spender, Amount:balance10  });
                      }}> 
                      <img src='/images/weth.png' width={20} alt='eth'/> {token10}: {`${Wei(balance10).substring(0,6)}`} 
                      </LINKSTYLED>
                      </p>
                            </>
                          ) : (
                            <>
                          <p style={{textAlign: "center", color: 'white', fontSize: '1rem', fontWeight: 'bolder'}}>
                          <img src='/images/weth.png' width={20} alt='eth'/> {token10}: 0
                      </p>                           
                            </>
                          )}




                          

                  </div>
              </div>
          </div>
      </div>
  )
};






  return (

    <Screen>
    <Header connect={connect} account={account}/>
    <InputDiv >

    {account === null ? (
      <>
          <h3>
     Connect your Wallet
    </h3>
      </>
    ) : (
      <>
          <h3>
     Paste Address
    </h3>
      </>
    )}

    {account === null ? (
      <>
          <InputGroup inside style={styles}>
      <Input disabled placeholder={"Connect Your Wallet"} type={"text"} 
      onChange={ e => {setaccount(e)}}
      ref={accountInputRef} value={account}
      />
    </InputGroup>
      </>
    ) : (
      <>
          <InputGroup inside style={styles}>
      <Input placeholder={"0xb76ff1C10e9F0D013c0fF5fB9D8c9a5dCda322AF"} type={"text"} 
      onChange={ e => {setaccount(e)}}
      ref={accountInputRef} value={account}
      />
      <InputGroup.Button
      onClick={(e) => {
        e.preventDefault();
        connect();
      }}
      >
        {account === null ? (
          <>
          Connect Wallet
          </>
        ) : (
          <>
          Use your Address
          </>
        )
        }
        
      </InputGroup.Button>
    </InputGroup>
      </>
    )}

    <MSGDiv>
      <ERRMSG>
    {msg}
    </ERRMSG>
    </MSGDiv>
{account === null ? (
  <>
        <Button
          onClick={(e) => {
            e.preventDefault();
            connect();
          }}>
      Connect
    </Button>
  </>
) : (
  <>
      <Button
          onClick={(e) => {
            e.preventDefault();
            Search();
            SearchB();
            checkallowance();
          }}>
      Search
    </Button>
  </>
)}


    </InputDiv>


    <InputDivResult>
    <h1 style={{color: 'cyan'}}>
      Balance
    </h1>

     <ResultDiv2>
                      <BalanceofUser balance={Wei(Balance).substring(0,6)}>
                      </BalanceofUser>
                      
     </ResultDiv2>

    <ResultDiv>

    { Tokens.length > 0 ? Tokens.map(Token => {
                       
                       return (
                          <TokensofUser name={Token.name} balance={Token.balance} symbol={Token.symbol} contract={Token.contractAddress}>
                          </TokensofUser>
                       )
                   }) : 
                   <div>
                     <ERRMSG>
                     No Tokens found
                     </ERRMSG>
                     </div>}
</ResultDiv>
    </InputDivResult>


    <InputDivResult>
    <h1 style={{color: 'cyan'}}>
      Allowance
    </h1>
    <SwapDiv>
    <ResultDivAllow>

                          <AllowofUser name={"VallySwap"} Spender={VallyswapFarm}
                          token={"Vally"} balance={VallyAL} token2={"Bling"} balance2={BlingAL}
                          token3={"Yuzu"} balance3={YuzuAL} token4={"Weth"} balance4={WethAL}
                          token5={"ceUSDC"} balance5={ceUSDCAL} token6={"FTP"} balance6={FTPAL}
                          token7={"WeUSDT"} balance7={weUSDTAL} token8={"BTC"} balance8={BTCAL}
                          token9={"USDC"} balance9={USDCAL} token10={"ETH"} balance10={ETHAL}
                          token11={"USDT"} balance11={USDTAL} token12={"LINK"} balance12={LINKAL}
                          token13={"WROSE"} balance13={WROSEAL} url={Vallyswaptokenadd}
                          Contract={VallyCT} Contract2={BlingCT} Contract3={YuzuCT} Contract4={WethCT}
                          Contract5={ceUSDCCT} Contract6={FTPCT} Contract7={weUSDTCT} Contract8={BTCCT}
                          Contract9={USDCCT} Contract10={ETHCT} Contract11={USDTCT} Contract12={LINKCT}
                          Contract13={WROSECT}
                          >
                          </AllowofUser> 
</ResultDivAllow>

<ResultDivAllow>

                          <AllowofUser name={"GemKeeperSwap"} Spender={MasterChefFarm}
                          token={"Vally"} balance={VallyAL2} token2={"Bling"} balance2={BlingAL2}
                          token3={"Yuzu"} balance3={YuzuAL2} token4={"Weth"} balance4={WethAL2}
                          token5={"ceUSDC"} balance5={ceUSDCAL2} token6={"FTP"} balance6={FTPAL2}
                          token7={"WeUSDT"} balance7={weUSDTAL2} token8={"BTC"} balance8={BTCAL2}
                          token9={"USDC"} balance9={USDCAL2} token10={"ETH"} balance10={ETHAL2}
                          token11={"USDT"} balance11={USDTAL2} token12={"LINK"} balance12={LINKAL2}
                          token13={"WROSE"} balance13={WROSEAL2} url={blingadd}
                          Contract={VallyCT} Contract2={BlingCT} Contract3={YuzuCT} Contract4={WethCT}
                          Contract5={ceUSDCCT} Contract6={FTPCT} Contract7={weUSDTCT} Contract8={BTCCT}
                          Contract9={USDCCT} Contract10={ETHCT} Contract11={USDTCT} Contract12={LINKCT}
                          Contract13={WROSECT}
                          >
                      </AllowofUser> 
</ResultDivAllow>

<ResultDivAllow>

                          <AllowofUser name={"YuzuSwap"} Spender={yuzuPark}
                          token={"Vally"} balance={VallyAL3} token2={"Bling"} balance2={BlingAL3}
                          token3={"Yuzu"} balance3={YuzuAL3} token4={"Weth"} balance4={WethAL3}
                          token5={"ceUSDC"} balance5={ceUSDCAL3} token6={"FTP"} balance6={FTPAL3}
                          token7={"WeUSDT"} balance7={weUSDTAL3} token8={"BTC"} balance8={BTCAL3}
                          token9={"USDC"} balance9={USDCAL3} token10={"ETH"} balance10={ETHAL3}
                          token11={"USDT"} balance11={USDTAL3} token12={"LINK"} balance12={LINKAL3}
                          token13={"WROSE"} balance13={WROSEAL3} url={yuzutokenadd}
                          Contract={VallyCT} Contract2={BlingCT} Contract3={YuzuCT} Contract4={WethCT}
                          Contract5={ceUSDCCT} Contract6={FTPCT} Contract7={weUSDTCT} Contract8={BTCCT}
                          Contract9={USDCCT} Contract10={ETHCT} Contract11={USDTCT} Contract12={LINKCT}
                          Contract13={WROSECT}
                          >
                      </AllowofUser> 
</ResultDivAllow>


</SwapDiv>
    </InputDivResult>



    <InputDivResult>
    <SwapDiv>

    <ResultDivAllow>

<AllowofUser name={"Uniswap 2"} Spender={Uniswap}
token={"Vally"} balance={VallyAL4} token2={"Bling"} balance2={BlingAL4}
token3={"Yuzu"} balance3={YuzuAL4} token4={"Weth"} balance4={WethAL4}
token5={"ceUSDC"} balance5={ceUSDCAL4} token6={"FTP"} balance6={FTPAL4}
token7={"WeUSDT"} balance7={weUSDTAL4} token8={"BTC"} balance8={BTCAL4}
token9={"USDC"} balance9={USDCAL4} token10={"ETH"} balance10={ETHAL4}
token11={"USDT"} balance11={USDTAL4} token12={"LINK"} balance12={LINKAL4}
token13={"WROSE"} balance13={WROSEAL4} url={yuzutokenadd}
Contract={VallyCT} Contract2={BlingCT} Contract3={YuzuCT} Contract4={WethCT}
Contract5={ceUSDCCT} Contract6={FTPCT} Contract7={weUSDTCT} Contract8={BTCCT}
Contract9={USDCCT} Contract10={ETHCT} Contract11={USDTCT} Contract12={LINKCT}
Contract13={WROSECT}
>
</AllowofUser> 

</ResultDivAllow>

<ResultDivAllow>

<AllowofUser2 name={"Evodefi Bridge"} Spender={bridgeoasis}
 token4={"Weth"} balance4={WethAL5} token9={"USDC"} balance9={USDCAL5} token10={"ETH"} balance10={ETHAL5}
 Contract4={WethCT} Contract9={USDCCT} Contract10={ETHCT}
>
</AllowofUser2> 

</ResultDivAllow>


</SwapDiv>
    </InputDivResult>





    </Screen>
  );
}

export default App;
